# PrimeFacesAdminLTE

* *Author* : Ömer Faruk KURT
* *Technologies* : Java EE 7 (JSF 2.2, JPA 2.1,EJB Lite 3.2, CDI 1.1, Bean Validation 1.1), PrimeFaces 6.0, Bootstrap 3.x, FontAwesome 4.x, JQuery 2.x , WickedChart 1.6 , JSoup 1.8.3
* *Application Servers* : Glassfish 4
* *DB* : Mysql 5.x

* *PrimeFaces Admin LTE*
https://www.youtube.com/watch?v=v_DQ2tFV9kY

* *PrimeFaces Admin LTE 2*
https://www.youtube.com/watch?v=NyUYFgbF8DE

* *PrimeFaces Admin LTE Crud*
https://www.youtube.com/watch?v=U0ihW8Iserw

* *PrimeFaces Admin LTE - Audit *
https://www.youtube.com/watch?v=d2iYSnCMBfQ


## Test this application on OpenShift 
* *username* : Mike  
* *password* : Mike

<a href="http://admin-kurtomerfaruk.rhcloud.com/Admin/login.xhtml"><img src="https://allclouds.net/wp-content/uploads/2015/08/OpenShift-Logo-e1440595191561.png"/></a>


##WickedChart jar Download
* http://www.megafileupload.com/o68R/wickedcharts.rar


## Screenshot
<img src='https://s9.postimg.org/5fhhr35gb/Admin_LTE1.png'/>
<img src='https://s9.postimg.org/gn8am6baz/Admin_LTE3.png'/>




