package com.kurtomerfaruk.admin.dao;

/**
 *
 * @author Omer Faruk KURT e-mail:kurtomerfaruk@gmail.com
 * @param <T>
 */
public interface ILanguageDAO<T> extends IGenericDAO<T>{
    
}
