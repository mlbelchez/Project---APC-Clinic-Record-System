package com.kurtomerfaruk.admin.dao;

/**
 *
 * @author Omer Faruk KURT e-mail:kurtomerfaruk@gmail.com
 * @param <T>
 */
public interface ICountryDAO<T> extends IGenericDAO<T>{
    
}
