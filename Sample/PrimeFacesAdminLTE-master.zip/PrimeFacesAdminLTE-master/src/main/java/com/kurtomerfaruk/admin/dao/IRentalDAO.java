package com.kurtomerfaruk.admin.dao;

/**
 *
 * @author Omer Faruk KURT e-mail:kurtomerfaruk@gmail.com
 * @param <T>
 */
public interface IRentalDAO<T> extends IGenericDAO<T>{
    
}
