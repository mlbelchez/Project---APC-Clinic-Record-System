package com.kurtomerfaruk.admin.dao;

/**
 *
 * @author Omer Faruk KURT kurtomerfaruk@gmail.com
 * @param <T>
 */
public interface IActorDAO<T> extends IGenericDAO<T> {

}
